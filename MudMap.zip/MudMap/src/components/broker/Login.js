import React from "react";
import { Formik, Form } from "formik";
import * as Yup from "yup";
import Controls from "../Controls";
import {
  Card,
  CardActions,
  CardContent,
  Grid,
  Typography,
} from "@mui/material";

export const Login = () => {
  return (
    <Formik
      initialValues={{ username: "", password: "" }}
      validationSchema={Yup.object({
        username: Yup.string()
          .max(15, "Must be 15 characters or less")
          .required("this field Required "),
        password: Yup.string()
          .max(20, "Must be 20 characters or less")
          .required("Required"),
      })}
      onSubmit={(values, { setSubmitting }) => {
        console.log(values);
        alert(JSON.stringify(values, null, 2));
      }}>
      <Card sx={{ maxWidth: 345, margin: "auto" }}>
        <CardContent>
          <Typography gutterBottom variant='h5' component='div'>
            Login
          </Typography>
          <Typography variant='body2' component='div' color='text.secondary'>
            <div
              className='content'
              style={{ width: "300px", margin: "auto", padding: "10px" }}>
              <Form>
                <Grid>
                  <Controls.TextField
                    name='username'
                    variant='outlined'
                    label='Username'
                  />
                </Grid>
                <Grid>
                  <Controls.TextField
                    type='password'
                    name='password'
                    variant='outlined'
                    label='Password'
                  />
                </Grid>
              </Form>
            </div>
          </Typography>
        </CardContent>
        <CardActions>
          <Controls.Button type='submit' variant='contained' color='success'>
            Login
          </Controls.Button>
        </CardActions>
      </Card>
    </Formik>
  );
};
