import React from "react";
import { Formik, Form } from "formik";
import * as Yup from "yup";
import Controls from "../Controls";
import {
  Card,
  CardActions,
  CardContent,
  Grid,
  Typography,
} from "@mui/material";

export const Register = () => {
  return (
    <Formik
      initialValues={{ firstName: "", lastName: "", email: "", mobile: "" }}
      validationSchema={Yup.object({
        firstName: Yup.string()
          .max(15, "Must be 15 characters or less")
          .required("Required"),
        lastName: Yup.string()
          .max(20, "Must be 20 characters or less")
          .required("Required"),
        email: Yup.string().email("Invalid email address").required("Required"),
        mobile: Yup.number().required(),
      })}
      onSubmit={(values, { setSubmitting }) => {
        alert(JSON.stringify(values, null, 2));
      }}>
      <Card sx={{ maxWidth: 345, margin: "auto" }}>
        <CardContent>
          <Typography gutterBottom variant='h5' component='div'>
            Register
          </Typography>
          <Typography variant='body2' color='text.secondary'>
            <div
              className='content'
              style={{ width: "300px", margin: "auto", padding: "10px" }}>
              <Form>
                <Grid>
                  <Controls.TextField
                    name='firstName'
                    variant='outlined'
                    label='Firstname'
                  />
                </Grid>
                <Grid>
                  <Controls.TextField
                    name='lastName'
                    variant='outlined'
                    label='Lastname'
                  />
                </Grid>
                <Grid>
                  <Controls.TextField
                    name='email'
                    variant='outlined'
                    label='Email'
                  />
                </Grid>
                <Grid>
                  <Controls.TextField
                    name='mobile'
                    variant='outlined'
                    label='Mobile'
                  />
                </Grid>
              </Form>
            </div>
          </Typography>
        </CardContent>
        <CardActions>
          <Controls.Button type='submit' variant='contained'>
            Register
          </Controls.Button>
          <Controls.Button color='warning' variant='contained'>
            Cancel
          </Controls.Button>
        </CardActions>
      </Card>
    </Formik>
  );
};
