import React from "react";

export const Header = () => {
  return (
    <div
      style={{
        height: "70px",
        backgroundColor: "#3c547a",
        color: "#FFF",
        marginBottom: "10px",
      }}>
      <h1 style={{ padding: "10px" }}>Cab Booking App</h1>
    </div>
  );
};
