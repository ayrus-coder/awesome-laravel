import { Header } from "./components/Header";
import { Login } from "./components/Rider/Login";
import { Register } from "./components/Rider/Register";

function App() {
  return (
    <div>
      {/* <Header /> */}
      {/* <Register /> */}
      <br />
      <Login />
    </div>
  );
}

export default App;
